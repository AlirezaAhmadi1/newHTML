let sideBar=document.getElementById("myNav");
function openNav(){
    sideBar.style.width="100%";
}
function closeNav(){
    sideBar.style.width="0";
}